###############################################
# Lebesgue Moment Matrix on an interval [a,b]
mom_mat<-function(a,b,d){
  # a,b : Upper and lower bound of the interval
  # d : degree up to which the moment matrix is computed
  # Returns a (d+1 x d+1) matrix with entries M[ij] = \int_a^b x^{i+j-2} dx
  M<-matrix(NA, nrow=d+1, ncol=d+1)
  for(i in 1:(d+1)){
    for(j in 1:(d+1)){
      M[i,j] = (b**(i+j-1) - a**(i+j-1))/(i+j-1)
    }
  }
  return(M)
}


###############################################
# Moment vector of a functional on an interval
mom_vec<-function(a,b,d,P, int.tol, int.subdiv){
  # a,b : Upper and lower bound of the interval
  # d : degree up to which the moment vector is computed
  # P : if P is numerical, it is assumed that it forms a step function. If P is
  #     a function, the integral is approximated using quadrature methods
  # ... : additional parameters to pass to the quadrature approximation function
  # Returns a vector of length d+1, with entries r[i] = int_a^b P(x)x^{i-1}dx
  r=rep(0, d+1)
  if(class(P)=="function"){
    #Quadrature
    f<-function(x,j){
      return((x^(j-1))*P(x))
    }
    for(i in 1:(d+1)){
      res<-integrate(f,
                     j=i,
                     lower=a,
                     upper=b,
                     subdivisions=int.subdiv,
                     rel.tol=int.tol)
      r[i]=res$value
    }
  }else{
    ###############
    #If the generalized inverse is empirical, compute the integral

    #Hidden function to compute the weights associated to the empirical integral
    weights_r<-function(j_down, J, j_up, i, n, a,b){
      w_J=sapply(J, function(x) (x+1)**(i) - x**i )
      w_J = w_J/(n**(i))

      w_jup<-(b**i - (j_up/n)**(i))
      w_jdown<-((j_down/n)**i - a**i)

      res=c(w_jdown, w_J, w_jup)/i
      return(res)
    }

    #Setting-up parameters
    n=length(P)
    P_=sort(P)
    J=seq(floor(n*a)+1, floor(n*b)-1, 1)
    if(a==0){
      j_up=floor(b*n)
      j_down=1
    }else if (b==1){
      j_down=floor(a*n)+1
      j_up=n
    }else{
      j_up=floor(b*n)
      j_down=floor(a*n)+1
    }

    #Vector of relevant order statistics
    X_=P_[c(j_down, J, j_up)]

    #Computing each element of r
    for(i in 1:(d+1)){
      wght_vec<-weights_r(j_down, J, j_up, i, n, a, b)
      r[i]=sum(X_*wght_vec)
    }
  }
  return(r)
}

###############################################
# Selection Matrices computations
I_mat<-function(i,d){
  # i : selected index
  # d : matrix size
  # Returns a (d x d) matrix of zeroes and ones. The ones are placed at I[k,l]
  #   whenever k+l=i+1
  I<-matrix(NA, nrow=d, ncol=d)
  for(k in 1:d){
    for(l in 1:d){
      if(k+l==i+1){
        I[k,l]=1
      }else{
        I[k,l]=0
      }

    }
  }
  return(I)
}

###############################################
# Matrix link positive poly & SOS poly
AB_mats<-function(d,a,b){
  # d : Polynomial Degree
  # a,b : bounds of the interval on which the pdf is defined
  # Returns two matrices of varying size (check theory)
  D=diag(1/seq(1,d,1))
  if(d%%2==0){
    I_up=rbind(diag(d-1), matrix(0,nrow=1, ncol=d-1))
    I_down=rbind(matrix(0,nrow=1, ncol=d-1),diag(d-1))
    A=D%*%(I_down - a*I_up)
    B=D%*%(b*I_up - I_down)
  }else{
    I_up=rbind(diag(d-2), matrix(0,nrow=2, ncol=d-2))
    I_down=rbind(matrix(0,nrow=2, ncol=d-2),diag(d-2))
    I_mid=rbind(matrix(0,nrow=1, ncol=d-2), diag(d-2), matrix(0,nrow=1, ncol=d-2))
    A=D
    B=D%*%((a+b)*I_mid - I_down - a*b*I_up)
  }
  return(list("A"=A, "B"=B))
}


##############################################
# Constraints function
build_consts<-function(s,z,w,Z,W,t_0,t_1,b_0,b_1,d){
  # s,z,w,Z,W : CVXR Variables of varying size
  # t_0, t_1 : Bounds of the interval on which P is valued
  # b_0,b_1 : Values of the equality constraints
  # d : Degree of the polynomial
  # P : Either a quantile function, or a sample
  # Returns a list of constraints to feed the CVXR solver

  # s : coefficients of the sought after polynomial
  # z,w : coefficients of the SOS polynomials upon which S decomposes
  # Z,W : SDP matrices upon which z and w decomposes


  ##########################################
  # Getting the matrices to link \breve{s}, z, and w
  const_mat=AB_mats(d, t_0, t_1)
  A=const_mat$A
  B=const_mat$B

  #####################################
  # Vectors to compute S(t_0) and S(t_1)
  # i.e., v_t_0 = (1, t_0, t_0^2, ... t_0^d)
  v_t_0<-sapply(seq(0,d,1), function(x) t_0^x)
  v_t_1<-sapply(seq(0,d,1), function(x) t_1^x)

  ######################################################
  #Size of objects will depend on the evenness of d

  #TODO parité à prendre en compte lors de la création des variables CVX
  d_z=dim(z)[1]
  d_w=dim(w)[1]

  d_Z=dim(Z)[1]
  d_W=dim(W)[1]


  #####################################
  # Setting up the result
  const=vector(mode="list", length=d_z+d_w+5)

  #####################################
  # Interpolation constraints
  const[[1]]= sum(s*v_t_0)== b_0 #S(t_0) = b_0
  const[[2]]= sum(s*v_t_1)== b_1 #S(t_1) = b_1

  #####################################
  # I_%*%s = \breve{s}, coefficients of S'(x)
  I_=cbind(rep(0,d),diag(d))

  #Linking the polynomial to the two SOS polynomials
  const[[3]]= I_%*%s== A%*%z + B%*%w #\breve{s} = Az + Bw

  ############################################
  # Series of linear maps from \Sigma_n to R^d

  #Representation of z wrt Z PSD
  for(i in 1:d_z){
    I=I_mat(i, d_Z)
    I_=rep(0,d_z)
    I_[i]=1
    const[[3+i]]= matrix_trace(I%*%Z) == t(I_)%*%z #<I_i, Z>_F = z_i
  }

  #Representation of w wrt W PSD
  for(i in 1:d_w){
    I=I_mat(i, d_W)
    I_=rep(0,d_w)
    I_[i]=1
    const[[3+d_z+i]]= matrix_trace(I%*%W) == t(I_)%*%w #<I_i, W>_F = w_i
  }

  #PSD constraints on Z and W
  const[[d_z+d_w+4]]= Z%>>%0
  const[[d_z+d_w+5]] = W%>>%0

  return(const)
}

###################################
# Get cadlag intervals
cadlag.interv<-function(alpha, beta){
  K=length(alpha)
  if(K==1){
    a=min(alpha,beta)
    b=max(alpha,beta)
  }else{
    a=rep(0,K)
    b=rep(0,K)
    for(i in 1:K){
      if(i==1){
        a[i] = min(c(alpha[i], beta[i]))
        b[i] = max( c(min(c(alpha[i], beta[i+1])), beta[i]))
      }else if (i==K){
        a[i] = min( c(max(c(beta[i-1], alpha[i])), beta[i]))
        b[i] = max(c(alpha[i], beta[i]))
      }else{
        a[i] = min( c(max(c(beta[i-1], alpha[i])), beta[i]))
        b[i] = max( c(min(c(alpha[i], beta[i+1])), beta[i]))
      }
    }
  }
  return(list("a"=a,
              "b"=b))
}




