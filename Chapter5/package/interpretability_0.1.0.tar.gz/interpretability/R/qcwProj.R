#TODO:
# Surcharger méthodes : plot, sample, (transport ?), evaluate
# Objet S3 (ou S4, mais ça serait relou...) de manière générique
# PERTURBATION CADLAG
# Docu

#####################
#Piecewise polynomial solution
qcwProj.poly<-function(grd_cst, P, minP, maxP, d, opt.max.iter, int.tol, int.subdiv){

  if(class(P)!="function"){
    P=c(minP, P, maxP)
  }
  #Getting the grid parameters
  if(class(grd_cst)=="list"){
    #In the event where alpha or beta are null
    t_0=grd_cst$t_0
    t_1=grd_cst$t_1
    b_0=grd_cst$b_0
    b_1=grd_cst$b_1
  }else{
    t_0=grd_cst[1]
    t_1=grd_cst[2]
    b_0=grd_cst[3]
    b_1=grd_cst[4]
  }

  #Moment matrix and vector
  M=mom_mat(t_0, t_1, d)
  r=mom_vec(t_0, t_1, d, P, int.tol=int.tol, int.subdiv=int.subdiv)

  #Setting-up the CVXR variables
  if(d%%2==0){#Even case
    s<-CVXR::Variable(rows=d+1, cols=1, name="s")
    z<-CVXR::Variable(rows=d-1, cols=1, name="z")
    w<-CVXR::Variable(rows=d-1, cols=1, name="w")

    Z<-CVXR::Variable(rows=d/2, cols=d/2, name="Z", symmetric=T)
    W<-CVXR::Variable(rows=d/2, cols=d/2, name="W", symmetric=T)
  }else{#Odd case
    s<-CVXR::Variable(rows=d+1, cols=1, name="s")
    z<-CVXR::Variable(rows=d, cols=1, name="z")
    w<-CVXR::Variable(rows=d-2, cols=1, name="w")

    Z<-CVXR::Variable(rows=((d-1)/2)+1, cols=((d-1)/2)+1, name="Z", symmetric=T)
    W<-CVXR::Variable(rows=((d-1)/2), cols=((d-1)/2), name="W", symmetric=T)
  }

  #Objective Function
  obj<-CVXR::Minimize(CVXR::quad_form(s,M)-2*t(r)%*%s)

  #Constraints
  constrs<-build_consts(s=s,
                        z=z,
                        w=w,
                        Z=Z,
                        W=W,
                        t_0=t_0,
                        t_1=t_1,
                        b_0=b_0,
                        b_1=b_1,
                        d=d)

  #Problem specification
  prob<-CVXR::Problem(obj, constrs)

  sol<-CVXR::solve(prob, num_iter=opt.max.iter)
  if(sol$status != "optimal"){
    warning(paste("The ",
                  sol$solver,
                  " solver has not found the optimal isotonic polynomial approximation on the [",
                  t_0,
                  ",",
                  t_1,
                  "] interval. \nReturned solver status: ",
                  sol$status,
                  ".\nYou might want to check either the validity of your quantile constraints, or increase the \'opt.max.iter\' argument value.",
                  sep=""))
  }

  res<-list("interval"=matrix(c(t_0,t_1), nrow=1),
            "coefs.poly"=sol$getValue(s),
            "solver.status"=sol$status,
            "solver.name"=sol$solver,
            "solver.nb_iter"=sol$num_iters,
            "obj.value"=sol$value,
            "z"=sol$getValue(z),
            "Z"=sol$getValue(Z),
            "w"=sol$getValue(w),
            "W"=sol$getValue(W)
            )
  return(res)
}

######################
# Master function
qcwProj<-function(X=NULL,
                  qFun=NULL,
                  cdFun=NULL,
                  alpha=NULL,
                  b=NULL,
                  type,
                  d,
                  OmegaX=NULL,
                  opt.max.iter=10e6,
                  int.tol =50*.Machine$double.eps,
                  int.subdiv=1e06,
                  par=NULL,
                  normalize=F){
  # X : data sample
  # P : Quantile function
  # alphas : levels of original quantile values
  # b : perturbed quantile values
  # OmegaX : Operating domain
  # type : either "cadlag" or "polynomial" depending on the tronche of the solution
  # d : polynomial degree
  # Returns something that I have to build in a smart way mais je sais pas encore comment

  #############################################
  # Ensuring argument types

  if(is.null(qFun) & is.null(X)){
    stop("Either one of the P or X argument must be specified.")
  }else if(all(is.null(qFun), is.null(X))){
    stop("X and P cannot be specified at the same time.")
  }

  #If the operating domain is not specified, infer it
  if(is.null(OmegaX)){
    if(is.null(qFun)){
      OmegaX<-c(min(P), max(P))
      message(paste("The operating domain has not been specified. Defaulted to [", OmegaX[1], ',',OmegaX[2],'].', sep=''))
    }else{
      OmegaX<-c(P(0), P(1))
      message(paste("The operating domain has not been specified. Defaulted to [", OmegaX[1], ',',OmegaX[2],'].', sep=''))
    }
  }

  OmegaX_=OmegaX
  if(normalize){
    if(is.null(X)){
      min.P=qFun(0)
      max.P=qFun(1)
      P_=qFun
      P<-function(x){
        res=(2/(max.P-min.P))*(qFun(x)-max.P) +1
        return(res)
        }
    }else{
      min.P=min(X)
      max.P=max(X)
      P_=X
      P<-(2/(max.P-min.P))*(X-max.P) +1
    }
    if(!is.null(OmegaX)){
      OmegaX=(2/(max.P-min.P))*(OmegaX-max.P) +1
      }
      b=(2/(max.P-min.P))*(b-max.P) +1
  }else{
    min.P=NULL
    max.P=NULL
    if(is.null(X)){
      P_=qFun
      P=qFun
    }else{
      P_=X
      P=X
    }
  }

  #Constraints parameters
  if(!is.null(alpha)){
    if(length(alpha)!=length(b)){
      stop("The alpha and b arguments must have the same length")
    }

    if(all.equal(order(alpha), order(b))==F){
      stop("The perturbation class is empty. Check the alpha and b parameters.")
    }
  }

  #Parallelization stuff
  if(!is.numeric(par)){
    if(!is.null(par)){
      stop("The 'parl' argument must be NULL or a positive integer.")
    }
  }else if(par%%1!=0 | par<0 | length(par)!=1){
    stop("The 'parl' argument must be NULL or a positive integer.")
  }else if (par>parallel::detectCores()){
    par=parallel::detectCores()-1
    warning(paste("Too many cores specified. Defaulted to ", par, " cores.", sep=""))
  }


  alpha=sort(alpha)
  b=sort(b)

  if(type=="cadlag"){
    #############################################
    # CADLAG FITTING
    # Récupérer les betas.

    # Getting each intervals
    intervals=cadlag.interv(alpha, beta)

    #Result
    res<-list("type"=type,
              "intervals"= intervals,
              "P"=c(minP, P),
              "alpha"=alpha,
              "beta"=beta)
    class(res)="qcwProj"
  }else if (type=="polynomial"){
    #############################################
    # ISOTONIC POLYNOMIAL FITTING

    #Number of constraints
    K=length(b)
    #Setting up the interpolation constraints
    t_0=c(0, alpha)
    t_1=c(alpha, 1)

    b_0<-c(OmegaX[1], b)
    b_1<-c(b, OmegaX[2])

    if(any(c(is.null(beta),is.null(alpha)))){
      grid_cnst<-matrix(c(0,1,b_0,b_1), nrow=1)
      colnames(grid_cnst)<-c("t_0", "t_1", "b_0", "b_1")
    }else{
      grid_cnst<-cbind(t_0,t_1,b_0,b_1)
    }
    if(is.null(par)){
    res.solv<-apply(grid_cnst, 1, qcwProj.poly,
                  P=P,
                  minP=OmegaX[1],
                  maxP=OmegaX[2],
                  d=d,
                  opt.max.iter=opt.max.iter,
                  int.tol=int.tol,
                  int.subdiv=int.subdiv)

    }else{
      cl<-parallel::makeCluster(par)
      parallel::clusterCall(cl, function() library(CVXR))
      res.solv<-parallel::parApply(cl,
                                grid_cnst, 1, qcwProj.poly,
                                P=P,
                                minP=OmegaX[1],
                                maxP=OmegaX[2],
                                d=d,
                                opt.max.iter=opt.max.iter,
                                int.tol=int.tol,
                                int.subdiv=int.subdiv)
      parallel::stopCluster(cl)
    }

    coefs<-matrix(NA, nrow=d+1, ncol=length(res.solv))

    for(i in 1:length(res.solv)){
      coefs[,i]=res.solv[[i]]$coefs.poly
    }



    res<-list("type"=type,
              "intervals"= grid_cnst,
              "P"=P_,
              "coefs"=coefs,
              "alpha"=alpha,
              "beta"=beta,
              "supportP"=OmegaX_,
              "d"=d,
              "res.solv"=res.solv,
              "normalize"=normalize,
              "min.P"=min.P,
              "max.P"=max.P)
    class(res)="qcwProj"
  }

  return(res)
}

####################
# Methods

####################
# Evaluate
# TODO : Commenter
evaluate.qcwProj<-function(qcwProj, x, ...){
  x<-as.vector(x)
  #Cadlag fitting
  if(qcwProj$type=="cadlag"){
    a<-qcwProj$intervals$a
    b<-qcwProj$intervals$b

    get_pert<-function(x,Q,a ,b, alpha){
      is_pert=any(x>= a & x<b)
      if(is_pert){
        idx_pert=which(x>= a & x<b)
        return(Q(alpha[idx_pert]))
      }else{
        return(as.numeric(Q(x)))
      }
    }

    if(class(qcwProj$P)!="function"){
      Q<-function(x){
        return(quantile(qcwProj$P, x, type=1))
      }
    }else{
      Q<-qcwProj$P
    }

    res<-sapply(x, get_pert,
                Q=Q,
                a=a,
                b=b,
                alpha=qcwProj$alpha)
  }else{
  #Polynomial fitting

    get_pert<-function(x, coefs, interv, d){

      if(x==0){
        idx_= 1
      }else if (x==1){
        idx_=nrow(interv)
      }else{
        idx_=which(x>=interv[,1] & x<interv[,2])[1]
      }

      X=sapply(seq(0,d), function(a) x^a)
      return(X%*%coefs[,idx_, drop=F])
    }

    res<-sapply(x, get_pert,
                coefs=qcwProj$coefs,
                interv=qcwProj$intervals[,c(1,2), drop=F],
                d=qcwProj$d,
                simplify=T)
  }

  if(class(res)=="list"){
    res=unlist(res)
  }
  if(qcwProj$normalize){
    res=(res-1)*((qcwProj$max.P-qcwProj$min.P)/2)+qcwProj$max.P
  }
  return(res)
}

####################
# Transport Method
transport.qcwProj<-function(qcwProj, n=NULL){
  if(class(qcwProj$P)=="function"){
    stop("P must be a data vector.")
  }

  if(is.null(n)){
    n<-length(qcwProj$P)
  }else if (!is.scalar(n)){
    stop("n must be a positive integer.")
  }

  return(evaluate(qcwProj, rank(qcwProj$P)/n))
}


##############
# Plot Method
plot.qcwProj<-function(qcwProj, seq.interv=0.001, legend=F, ylim=NULL, ...){
  x<-seq(0,1, seq.interv)
  interpol.x<-sort(unique(as.numeric(qcwProj$intervals[,c(1,2)])))
  interpol.y<-sort(unique(as.numeric(qcwProj$intervals[,c(3,4)])))

  if(qcwProj$normalize){
    interpol.y = (interpol.y-1)*((qcwProj$max.P-qcwProj$min.P)/2)+qcwProj$max.P
  }
  if(class(qcwProj$P)=="function"){
    plot.type="l"
    y<-qcwProj$P(x)
  }else{
    plot.type="s"
    y<-sort(c(qcwProj$supportP[1], qcwProj$P))
    n<-length(y)-1
    x<-seq(0,n)/n
  }

  if(is.null(ylim)){
    ylim=c(qcwProj$supportP[1],qcwProj$supportP[2])
  }
  y.pert=evaluate(qcwProj, x)


  plot(x,y, type=plot.type, col=1,
       ylim=ylim,
       xlim=c(0,1),
       ylab="Input Value",
       xlab="Quantile level",
       ...)

  grid()

  lines(x, y.pert,
        type=ifelse(qcwProj$type=="cadlag", "s", "l"),
        col=2,
        lwd=2,
        lty=5)

  points(x=interpol.x, y=interpol.y, lwd=2)
  if(!isFALSE(legend)){
    legend(legend,
           legend=c("Wasserstein Projection", "Initial Quantile Function", "Interpolation points"),
           lty=c(5,1, NA),
           col=c(2,1,1),
           pch=c(NA, NA, 1),
           lwd=c(2,1,2),
           cex=0.8)
  }

}
