#TODO :
# model mange X ou a une méthode predict
# Fonction de construction de theta

quantPert.Wass<-function(dataX, theta, poly.deg, add.const, type, method, OmegaX, normalize, ...){

  if(type=='dilatation'){
    opeDomain=c(theta[2], theta[3])

    if(is.null(add.const)){
      res.pert<-qcwProj(X=dataX,
                        alpha=NULL,
                        b=NULL,
                        OmegaX=opeDomain,
                        type=method,
                        d=poly.deg,
                        normalize=normalize,
                        ...)
    }else{
      res.pert<-qcwProj(X=dataX,
                        alpha=add.const[,1],
                        b=add.const[,2],
                        OmegaX=opeDomain,
                        type=method,
                        d=poly.deg,
                        normalize=normalize,
                        ...)
    }

  }else if(type=='shift'){

    if(is.null(add.const)){
      res.pert<-qcwProj(X=dataX,
                        alpha=theta[2],
                        b=theta[3],
                        OmegaX=OmegaX,
                        type=method,
                        d=poly.deg,
                        normalize=normalize,
                        ...)
    }else{
      alphas=c(theta[2],add.const[,1])
      bs=c(theta[3], add.const[,2])
      res.pert<-qcwProj(X=dataX,
                        alpha=alphas,
                        b=bs,
                        OmegaX=OmegaX,
                        type=method,
                        d=poly.deg,
                        normalize=normalize,
                        ...)
    }

  }
  return(res.pert)

}

robustPert<-function(X,
                     model,
                     pert.var,
                     theta.prec=0.1,
                     init.quant=NULL,
                     pert.range=NULL,
                     add.const=NULL,
                     OmegaX=NULL,
                     pertType=NULL,
                     method=c("polynomial",3),
                     X.trCost="l2",
                     Y.cost="l2",
                     par=NULL,
                     standard=F,
                     normalize=F,
                     ...){

  #If the operating domain is not specified, infer it
  if(is.null(OmegaX)){
    # if(is.null(qFun)){
      OmegaX<-c(min(X[,pert.var]), max(X[,pert.var]))
      message(paste("The operating domain has not been specified. Defaulted to [", OmegaX[1], ',',OmegaX[2],'].', sep=''))
    # }else{
    #   OmegaX<-c(P(0), P(1))
    #   message(paste("The operating domain has not been specified. Defaulted to [", OmegaX[1], ',',OmegaX[2],'].', sep=''))
    # }
  }

  #model.pert/theta et le reste ne peuvent pas être nulls

  #model.pert -> matrice alpha|b
  if(!is.null(pert.range)){
    theta=get_thetaGrid(theta.prec=theta.prec,
                        type=pertType,
                        OmegaX=pert.range,
                        init.quant=init.quant)
  }else{
    theta=get_thetaGrid(theta.prec=theta.prec,
                        type=pertType,
                        OmegaX=OmegaX,
                        init.quant=init.quant)
  }
  ############################################
  # Getting initial and perturbed predictions
  Y.hat<-matrix(model(X),ncol=1)




  #########################################
  # Gérer les coûts

  # # Transportation cost for x
  # if(X.trCost=="l2"){
  #   x.trCost<-function(x,y){
  #     return((x-y)^2)
  #   }
  # }
  #
  # # Prediction error cost
  # if(Y.cost=="l2"){
  #   y.cost<-function(x,y){
  #     return((x-y)^2)
  #   }
  # }
  #
  #


  #########################################
  # Quantile Perturbation using polynomials
  if(method[1]=="polynomial"){
    poly.degree=as.numeric(method[2])

    if(is.null(par)){
      res.pert<-apply(theta, 1, quantPert.Wass,
                      dataX=X[,pert.var],
                      poly.deg=poly.degree,
                      type=pertType,
                      method="polynomial",
                      OmegaX=OmegaX,
                      add.const=add.const,
                      normalize=normalize,
                      ...)
    }else{
      cl=parallel::makeCluster(par)

      res.pert<-parApply(cl, theta, 1, quantPert.Wass,
                         dataX=X[,pert.var],
                         poly.deg=poly.degree,
                         type=pertType,
                         method="polynomial",
                         OmegaX=OmegaX,
                         add.const=add.const,
                         normalize=normalize,
                         ...)
      parallel::stopCluster(cl)
    }
  }
  # }else if(pertType=="cadlag"){
  #   cl=parallel::makeCluster(par)
  #
  #   res.pert<-parApply(cl, theta, 1, quantPert.Wass,
  #                      dataX=X[,pert.var],
  #                      #poly.deg=poly.degree,
  #                      type="cadlag",
  #                      OmegaX=OmegaX,
  #                      ...)
  #   parallel::stopCluster(cl)
  # }

  pred.pert<-matrix(NA, nrow=nrow(theta), ncol=nrow(X)+1)
  pred.pert[,1]=theta[,1]

  dist.pert<-matrix(NA, nrow=nrow(theta), ncol=nrow(X)+1)
  dist.pert[,1]=theta[,1]

  obs.pert=pred.pert

  sensi.pert<-c(rep(NA, length(res.pert)))
  pert.data<-rep(list(0),length(res.pert))


  for(i in 1:length(res.pert)){
    X.pert<-transport(res.pert[[i]])
    obs.pert[i,2:(length(X.pert)+1)]<-X.pert
    X_<-X
    X_[,pert.var]<-X.pert

    Y.pert<-matrix(model(X_), ncol=1)
    pred.pert[i,2:(length(Y.pert)+1)]<-Y.pert

    pert.data[[i]]<-cbind(X_, Y.pert)

    sensi.pert[i]=mean(Y.pert)/mean(Y.hat)
    if(standard){
      dist.pert[i,-1] = rowSums((X - X_)^2)/(rowSums(X^2)*rowSums(X_^2))
    }else{
      dist.pert[i,-1] = rowSums((X - X_)^2)
    }

  }

  #
  #
  # sensi.pert<-c(rep(NA, length(res.pert)))
  # perturbs<-rep(list(0),length(res.pert))
  #
  # for(i in 1:length(res.pert)){
  #   X.pert<-transport(res.pert[[i]])
  #   X.init<-X[,pert.var]
  #   X_<-X
  #   X_[,pert.var]<-X.pert
  #
  #   Y.pert<-matrix(model(X_), ncol=1)
  #   Y.init<-Y.hat
  #
  #   data.pert1<-cbind(X.init, X.pert, Y.init, Y.pert)
  #
  #   #TODO: Bancal, à revoir
  #   if(standard==T){
  #     X.init<-standardize(X[,pert.var], mean(X[,pert.var]), sd(X[,pert.var]))
  #     X.pert<-standardize(X.pert, mean(X[,pert.var]), sd(X[,pert.var]))
  #
  #     Y.init<-standardize(Y.hat, mean(Y.hat), sd(Y.hat))
  #     Y.pert<-standardize(Y.pert, mean(Y.hat), sd(Y.hat))
  #   }
  #
  #   dif.X<-x.trCost(X.init, X.pert)
  #   dif.Y<-y.cost(Y.init,Y.pert)
  #
  #   perturbs[[i]]<-as.data.frame(cbind(data.pert1, dif.X, dif.Y, dif.Y/dif.X))
  #   colnames(perturbs[[i]])=c("X.initial", "X.perturbed","Y.initial","Y.perturbed","X.cost", "Y.cost", "YX.cost")
  #
  #   if(all(!c(dif.X!=0))){
  #     sensi.pert[i]=0
  #   }else if(all(dif.X!=0)){
  #     sensi.pert[i]<-mean(dif.Y/dif.X)
  #   }else{
  #     idx.keep=which(dif.X!=0)
  #     dif.Y<-y.cost(Y.init[idx.keep], Y.pert[idx.keep])
  #     dif.X<-x.trCost(X.init, X.pert[idx.keep])
  #     sensi.pert[i]<-mean(dif.Y/dif.X)
  #   }
  #
  # }

  res<-list("theta"=theta,
            "res.pert"=res.pert,
            "pert.data"=pert.data,
            "global.pert"=sensi.pert,
            "Y.init"=Y.hat,
            "pred.pert"=pred.pert,
            "obs.pert"=obs.pert,
            "dist.pert"=dist.pert)
            # "local.pert"=perturbs,
            # "x.cost"=X.trCost,
            # "y.cost"=Y.cost)
  class(res)="robustPert"
  return(res)
}


####################
# Methods


####################
# Plot method
plot.robustPert<-function(robustPert, type="global", leg=T, ...){
  if(type=="global"){
    plot.robustPert.global(robustPert, leg=T, ...)
  }else if (type=='local'){
    plot.robustPert.local(robustPert, leg=T, ...)
  }
}

##########################################
# Global sensitivity to perturbation plot

plot.robustPert.global<-function(robustPert, leg=T, ...){
  means<-sapply(robustPert$local.pert, function(x) mean(x$Y.cost))
  q9<-sapply(robustPert$local.pert, function(x) quantile(x$Y.cost, probs=0.9, type=1))
  q1<-sapply(robustPert$local.pert, function(x) quantile(x$Y.cost, probs=0.1, type=1))

  plot(robustPert$theta[,1], means,
       xlab=expression(theta),
       ylab="Mean prediction perturbation cost",
       ylim=c(min(q1), max(q9)),
       type='l',
       ...)

  graphics::polygon(x=c(robustPert$theta[,1], rev(robustPert$theta[,1])),
                    y=c(q9, rev(q1)),
                    col="gray90",
                    border=NA)
  lines(robustPert$theta[,1], means, lwd=2)
  grid()

  if(leg){
    legend("topright",
           legend=c("Mean prediction perturbation cost",
                    "10-90 percentiles"),
           lty=c(1,0),
           lwd=c(2,0),
           col=c(1,"gray90"),
           pch=c(NA, 15),
           bg="white",
           pt.cex=2,
           cex=0.8)
  }
}

##########################################
# Local sensitivity to perturbation plot
plot.robustPert.local<-function(robustPert, leg=T, set.mfrow=c(1,2), ...){
  nbPlot<-length(robustPert$res.pert)
  curr.mfrow=par(no.readonly = T)$mfrow
  par(mfrow=set.mfrow)
  for(i in 1:nbPlot){
    plot(robustPert$res.pert[[i]])
    plot(robustPert$local.pert[[i]]$X.initial, robustPert$local.pert[[i]]$YX.cost,
         xlab="Feature value",
         ylab="Prediction/Transportation cost ratio",
         ...)
  }
  par(mfrow=curr.mfrow)

}



