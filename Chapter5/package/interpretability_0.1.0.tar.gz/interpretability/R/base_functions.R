#TODO:
# Est-ce qu'on laisse le choix des valeurs b_0 ou juste alpha ?...
# Docu

###################################
#     METHODS INSTANCIATION       #
###################################

###################################
# Instanciate "evaluate" method
evaluate<-function(x,...)
  UseMethod("evaluate",x)

###################################
# Instanciate "transport" method
transport<-function(x,...)
  UseMethod("transport",x)


###################################
#     RANDOM USEFUL FUNCTIONS     #
###################################

###################################
#Checkes whether x is a scalar
is.scalar <- function(x) is.atomic(x) && length(x) == 1L

###################################
#Rescale vector to a,b
rescale<-function(X, a,b){
  return(a+((X-min(X))*(b-a))/(max(X)-min(X)))
}

###################################
#Standardization (0-mean, 1-variance)
standardize<-function(x, mean, sd){
  return((x-mean)/sd)
}


