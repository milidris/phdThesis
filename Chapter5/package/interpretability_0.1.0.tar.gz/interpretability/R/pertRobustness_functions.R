get_b<-function(theta, type, OmegaX=NULL, init.quant=NULL){
  if(is.null(OmegaX)){
    stop("OmegaX parameter must be specified.")
  }
  x_0=OmegaX[1]
  x_1=OmegaX[2]
  if(type=='dilatation'){
    if(theta<0){
      b_0=x_0-0.5*(theta*(x_1-x_0))
      b_1=x_1+0.5*(theta*(x_1-x_0))
    }else if(theta==0){
      b_0=x_0
      b_1=x_1
    }else if (theta>0){
      b_0=0.5*(x_0 - (x_0 - theta*x_1)/(theta-1))
      b_1=0.5*(x_1 + (theta*x_0 - x_1)/(theta-1))
    }
    return(c(b_0,b_1))
  }else if(type=='shift'){
    if(is.null(init.quant)){
      stop("init.quant parameter must be specified.")
    }
    if(theta<=0){
      b=init.quant*(1+theta)-theta*x_0
    }else{
      b=init.quant*(1-theta)+theta*x_1
    }
    return(b)
  }else{
    stop("Not implemented yet.")
  }
}

get_thetaGrid<-function(theta.prec, type, OmegaX, init.quant){
  if(type=="dilatation"){
    thetas<-seq(-1+theta.prec, 1-theta.prec, theta.prec)
    theta.res=sapply(thetas, get_b,
                     type=type,
                     OmegaX=OmegaX,
                     init.quant=init.quant)
    theta.grid=cbind(thetas, t(theta.res))
    colnames(theta.grid)=c("theta","b_0", "b_1")

  }else if(type=="shift"){
    thetas<-seq(-1, 1, theta.prec)
    theta.res=matrix(sapply(thetas, get_b,
                     type=type,
                     OmegaX=OmegaX,
                     init.quant=init.quant[2]), ncol=1)
    theta.grid=cbind(thetas, rep(init.quant[1], length(thetas)), theta.res)
    colnames(theta.grid)=c("theta","alpha", "b")
  }
  return(theta.grid)
}

